[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>