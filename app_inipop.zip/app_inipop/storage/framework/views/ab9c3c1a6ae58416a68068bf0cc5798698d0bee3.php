<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Bienvenido ya puede realizar la carga de las cedulas')); ?></div>

                <div class="card-body">
                     <?php if(Session::has('message')): ?>
          
                      <div class="alert alert-<?php echo e(Session::get('typealert')); ?>" style="display: none;">
                        <?php echo e(Session::get('message')); ?>

                        <?php if($errors->any()): ?>
                          <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <?php endif; ?>
                        <script>
                          $('.alert').slideDown();
                          setTimeout(function(){ $('.alert').slideUp();},10000);
                        </script>
                      </div>
                    
                  <?php endif; ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nro cedula')); ?></label>

                            <div class="col-md-6">
                                <input id="nrocedula" type="input" class="form-control" name="nrocedula" value="<?php echo e(old('nrocedula')); ?>" required  autofocus>

                                
                            </div>

                        </div>
                    <div class="col-md-8 offset-md-4">
                                <button type="button" class="btn btn-primary">
                                    <?php echo e(__('Agregar')); ?>

                                </button>

                                 <button type="button" class="btn btn-primary">
                                    <?php echo e(__('Generar Certificado')); ?>

                                </button>
                            </div>
                    
    
                </div>

            </div>
        </div>
          <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Cedulas Registradas hasta el momento')); ?></div>

                <div class="card-body">
                     
                        <table class="table table-hover">
                       
                      <thead>

                        <tr>
                          <th>Id</th>
                          <th>Nro cedula</th>
                          <th>Nombre y Apellido</th>
                          <th>Verificado</th>
                          <th>Ya esta Participando</th>
                          <th>Accion</th>
                        </tr>
                      </thead>
                    

                      <tbody>
                       
                        <tr>
                          <td>1</td>
                          <td>5556668</td>
                          <td>preuba prueba</td>
                          <td>Si</td>
                          <td>No</td>
                          <td><a class="link" href=""><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
                           <a class="link" href=""> <span class="glyphicon-class"></span>
                          <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                            <span class="glyphicon-class"></span></a>
                          </td>
                        </tr>
                       
                      </tbody>
                    </table>
                    
                    Una vez registradas 30 cedulas verificadas se podra solicitar la generacion del certificado.
                

                <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(100)->generate('Transfórmame en un QrCode!')); ?> ">
</div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\resources\views/home.blade.php ENDPATH**/ ?>