

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                   <h6 align="center"> PLATAFORMA DE GESTIÓN PARA VOLUNTARIOS<br>
                DEL PROYECTO DE LEY DE INICIATICA POPULAR<br>
                “MÁS EDUCACIÓN, MENOS BUROCRACIA”</h6>
                <div class="col-12 text-center"><strong> <h2>Módulo de Registro</h2> </strong></div>

                    <img class="rounded mx-auto d-block" src="<?php echo e(URL::asset('/imagenes/Mas_Educacion_Logo.png')); ?>" alt="" height="200" width="200"></div>
                <?php if(Session::has('message')): ?>
          
                      <div class="alert alert-<?php echo e(Session::get('typealert')); ?>" style="display: none;">
                        <?php echo e(Session::get('message')); ?>

                        <?php if($errors->any()): ?>
                          <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <?php endif; ?>
                        <script>
                          $('.alert').slideDown();
                          setTimeout(function(){ $('.alert').slideUp();},10000);
                        </script>
                      </div>
                    
                  <?php endif; ?>
                <div class="card-body">
                    <form action="<?php echo e(url('/registro/alta/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Iniciativa')); ?></label>

                            <div class="col-md-6">
                                <select name='cod_iniciativa' id="cod_iniciativa" class="form-select" >
                                     <option value="">Elija una Iniciativa</option>
                                    <?php $__currentLoopData = $iniciativas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iniciativa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option selected  value="<?php echo e($iniciativa->cod_iniciativa); ?>"><?php echo e($iniciativa->nombre_iniciativa); ?>

                                      
                                  </option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="universidad" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Universidad')); ?></label>

                            <div class="col-md-6">
                                <select name='cod_universidad' id="cod_universidad" class="form-select" >
                                  
                                  <option value="">Elija una Universidad</option>
                                  <?php $__currentLoopData = $Universidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Universidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($Universidad->cod_universidad); ?>" ><?php echo e($Universidad->nombre_universidad); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </select>

                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="facultad" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Facultad')); ?></label>

                            <div class="col-md-6">
                                <select id="cod_facultad" name='cod_facultad' class="form-select" >
                                  
                                </select>

                            </div>
                        </div>
                         <div class="row mb-3">
                            <label for="sede" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Sede')); ?></label>

                            <div class="col-md-6">
                                <select id="cod_sede" name='cod_sede' class="form-select" >
                                  
                                </select>

                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="carrera" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Carrera')); ?></label>

                            <div class="col-md-6">
                                <input id="carrera" type="text" class="form-control <?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="carrera" value="<?php echo e(old('carrera')); ?>" required autocomplete="carrera" autofocus>

                                <?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="nombres" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nombres')); ?></label>

                            <div class="col-md-6">
                                <input id="nombres" type="text" class="form-control <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombres" value="<?php echo e(old('nombres')); ?>" required autocomplete="nombres" autofocus>

                                <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                         <div class="row mb-3">
                            <label for="apellidos" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Apellidos')); ?></label>

                            <div class="col-md-6">
                                <input id="apellidos" type="text" class="form-control <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="apellidos" value="<?php echo e(old('apellidos')); ?>" required autocomplete="apellidos" autofocus>

                                <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                         <div class="row mb-3">
                            <label for="nro_cedula" class="col-md-4 col-form-label text-md-end">Nro de Cédula'</label>

                            <div class="col-md-6">
                                <input id="nrocedula" type="text" class="form-control <?php $__errorArgs = ['nrocedula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nrocedula" value="<?php echo e(old('nrocedula')); ?>" required autocomplete="nrocedula" autofocus>

                                <?php $__errorArgs = ['nrocedula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">Correo Electrónico</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="nro_celular" class="col-md-4 col-form-label text-md-end">Nro de Celular</label>

                            <div class="col-md-6">
                                <input id="nro_celular" type="text" class="form-control <?php $__errorArgs = ['nro_celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nro_celular" value="<?php echo e(old('nro_celular')); ?>" required autocomplete="nro_celular" autofocus>

                                <?php $__errorArgs = ['nro_celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                         <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">Confirmar Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        

                        <div class="row mb-0" align="center">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Enviar datos para registrarte
                                </button>
                                 <a type="button" href="<?php echo e(url('/home')); ?>" class="btn btn-primary">
                                    Cancelar
                                </a>
                            </div>
                            
                        </div>
                         <div class="row">
            <div class="col-md-12">
                
                <p align="center"><strong>Una vez enviados los datos de registro, te enviaremos un e-mail desde la dirección info@participapy.com para confirmar tu e-mail y completar el registro. También te enviaremos toda la información y los instructivos para que puedas realizar la difusión de esta iniciativa popular. Ten presente que ese email podría estar en la bandeja de correos no deseados o de spam.</strong>
</p>
            </div>
    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/altas.js')); ?>" type="text/javascript">

 
</script>


<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\resources\views/registro/alta.blade.php ENDPATH**/ ?>