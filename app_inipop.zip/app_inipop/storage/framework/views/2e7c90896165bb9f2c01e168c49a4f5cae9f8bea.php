<?php echo e($slot); ?>

<?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>