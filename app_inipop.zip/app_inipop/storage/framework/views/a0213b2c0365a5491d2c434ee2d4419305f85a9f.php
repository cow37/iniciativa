<div class="container">Certificado obtenido para extension
	 <?php $__currentLoopData = $datos_certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos_certificado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 <?php echo e($datos_certificado->nombres); ?>

	 <br>
	 <?php echo e($datos_certificado->nro_cedula); ?>

	 <br>
	  <?php echo e($datos_certificado->nombre_facultad); ?>

	 <br>
	   <?php echo e($datos_certificado->nombre_universidad); ?>

	 <br>
	 <?php echo e($datos_certificado->cantidad_registrada); ?>

	 	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 	 <br>


<img src="data:image/png;base64, <?php echo $qrcode; ?>"><?php echo e($nombres); ?>

</div><?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\resources\views/registro/PDFS/Certificado.blade.php ENDPATH**/ ?>