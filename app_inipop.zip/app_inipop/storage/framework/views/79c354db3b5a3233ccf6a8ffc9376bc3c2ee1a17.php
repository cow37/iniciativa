Se reenvio el correo exitosamente!!!
Ingresar desde el correo electronico<?php /**PATH E:\PROYECTOS\APP_INIPOP\app_inipop\resources\views/registro/reenviook.blade.php ENDPATH**/ ?>